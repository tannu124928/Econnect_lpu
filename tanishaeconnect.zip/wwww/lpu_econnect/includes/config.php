<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');        // Change to your MySQL username
define('DB_PASS', '');            // Change to your MySQL password
define('DB_NAME', 'lpu_econnect');

$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$conn) {
    die("<div style='font-family:sans-serif;padding:30px;color:red;'>
        <h2>Database Connection Failed</h2>
        <p>" . mysqli_connect_error() . "</p>
        <p>Please import <strong>database.sql</strong> in phpMyAdmin and update credentials in <strong>includes/config.php</strong></p>
    </div>");
}

mysqli_set_charset($conn, "utf8");

// Session start
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('SITE_NAME', 'LPU eConnect');
define('SITE_URL', 'http://localhost/lpu_econnect');
?>
