<?php
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

$type     = $_SESSION['user_type'];
$name     = $_SESSION['user_name'];
$uid      = $_SESSION['user_uid'];
$initials = strtoupper(substr($name, 0, 1) . (strpos($name,' ') !== false ? substr(strstr($name,' '),1,1) : ''));
$current  = basename($_SERVER['PHP_SELF']);
?>
<div class="sidebar">
  <div class="sidebar-brand">
    <div class="sidebar-brand-icon">🎓</div>
    <div class="sidebar-brand-name">LPU eConnect</div>
  </div>

  <div class="sidebar-section">Main</div>
  <a href="dashboard.php" class="nav-link <?= $current=='dashboard.php'?'active':'' ?>">
    <span class="nav-icon">🏠</span> Dashboard
  </a>

  <?php if ($type === 'student'): ?>
  <div class="sidebar-section">Academics</div>
  <a href="attendance.php" class="nav-link <?= $current=='attendance.php'?'active':'' ?>">
    <span class="nav-icon">📊</span> Attendance
  </a>
  <a href="results.php" class="nav-link <?= $current=='results.php'?'active':'' ?>">
    <span class="nav-icon">📝</span> Results & Marks
  </a>
  <a href="timetable.php" class="nav-link <?= $current=='timetable.php'?'active':'' ?>">
    <span class="nav-icon">🗓️</span> Timetable
  </a>
  <a href="fees.php" class="nav-link <?= $current=='fees.php'?'active':'' ?>">
    <span class="nav-icon">💳</span> Fee Status
  </a>

  <?php else: ?>
  <div class="sidebar-section">Faculty</div>
  <a href="students.php" class="nav-link <?= $current=='students.php'?'active':'' ?>">
    <span class="nav-icon">👨‍🎓</span> Students
  </a>
  <a href="mark_attendance.php" class="nav-link <?= $current=='mark_attendance.php'?'active':'' ?>">
    <span class="nav-icon">✅</span> Mark Attendance
  </a>
  <a href="add_marks.php" class="nav-link <?= $current=='add_marks.php'?'active':'' ?>">
    <span class="nav-icon">📝</span> Add Marks
  </a>
  <?php endif; ?>

  <div class="sidebar-section">General</div>
  <a href="notices.php" class="nav-link <?= $current=='notices.php'?'active':'' ?>">
    <span class="nav-icon">🔔</span> Notices
  </a>
  <a href="profile.php" class="nav-link <?= $current=='profile.php'?'active':'' ?>">
    <span class="nav-icon">👤</span> Profile
  </a>

  <div class="sidebar-footer">
    <div class="user-card">
      <div class="user-avatar"><?= $initials ?></div>
      <div class="user-info">
        <div class="user-name"><?= htmlspecialchars($name) ?></div>
        <div class="user-role"><?= $uid ?> · <?= ucfirst($type) ?></div>
      </div>
    </div>
    <a href="logout.php" class="btn btn-outline" style="width:100%;margin-top:10px;justify-content:center;">
      🚪 Logout
    </a>
  </div>
</div>
